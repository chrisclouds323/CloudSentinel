import base64
import json
import os

def detect_threat(event, context):
    pubsub_message = base64.b64decode(event['data']).decode('utf-8')
    log_entry = json.loads(pubsub_message)

    alert_channel = os.getenv('ALERT_CHANNEL', 'slack')

    print("🔐 Threat Detected!")
    print("Log Entry:", json.dumps(log_entry, indent=2))

    # Sample logic — alert on sensitive IAM changes
    method_name = log_entry.get("protoPayload", {}).get("methodName", "")
    if "SetIamPolicy" in method_name or "CreateServiceAccountKey" in method_name:
        print(f"[ALERT] IAM threat detected: {method_name}")
        # Extend: send alert to Slack, email, webhook, etc.
